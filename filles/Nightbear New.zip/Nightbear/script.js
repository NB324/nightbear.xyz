class EditorTab {
    constructor(_0x109d52 = "untitled.lua", _0x4fb06a = '') {
      this.title = _0x109d52;
      this.content = _0x4fb06a;
      this.element = null;
    }
    ["createTabElement"]() {
      const _0x437053 = document.createElement("div");
      _0x437053.className = "tab";
      _0x437053.innerHTML = "\n            <span class=\"tab-title\" contenteditable=\"false\">" + this.title + "</span>\n            <button class=\"tab-close\">X</button>\n        ";
      const _0x1dcc4c = _0x437053.querySelector(".tab-title");
      _0x1dcc4c.addEventListener('dblclick', _0x1a8ec6 => {
        _0x1a8ec6.stopPropagation();
        _0x1dcc4c.contentEditable = true;
        _0x1dcc4c.focus();
        const _0x2b6452 = document.createRange();
        _0x2b6452.selectNodeContents(_0x1dcc4c);
        const _0x3b524c = window.getSelection();
        _0x3b524c.removeAllRanges();
        _0x3b524c.addRange(_0x2b6452);
      });
      _0x1dcc4c.addEventListener('blur', () => {
        _0x1dcc4c.contentEditable = false;
        this.title = _0x1dcc4c.textContent.trim() || "untitled.lua";
        _0x1dcc4c.textContent = this.title;
      });
      _0x1dcc4c.addEventListener('keydown', _0x15b08c => {
        if (_0x15b08c.key === "Enter") {
          _0x15b08c.preventDefault();
          _0x1dcc4c.blur();
        }
      });
      this.element = _0x437053;
      return _0x437053;
    }
  }
  class Editor {
    constructor() {
      this.showLoadingScreen();
      this.tabs = [];
      this.activeTab = null;
      this.editor = null;
      this.themes = {
        'vs-dark': {
          'base': "vs-dark",
          'inherit': false,
          'rules': [{
            'token': "keyword",
            'foreground': "#569CD6"
          }, {
            'token': "identifier",
            'foreground': '#9CDCFE'
          }, {
            'token': "string",
            'foreground': "#CE9178"
          }, {
            'token': "number",
            'foreground': "#B5CEA8"
          }, {
            'token': "comment",
            'foreground': "#6A9955"
          }, {
            'token': "operator",
            'foreground': "#D4D4D4"
          }, {
            'token': 'delimiter',
            'foreground': "#D4D4D4"
          }, {
            'token': "function",
            'foreground': "#DCDCAA"
          }],
          'colors': {
            'editor.background': "#1E1E1E",
            'editor.foreground': "#D4D4D4",
            'editor.lineHighlightBackground': '#2D2D2D',
            'editorLineNumber.foreground': '#858585',
            'editor.selectionBackground': "#264F78",
            'tab.activeBackground': "#1E1E1E",
            'tab.inactiveBackground': "#2D2D2D",
            'tab.border': "#ff0000",
            'tab.activeBorderTop': "#ff0000"
          }
        },
        'monokai': {
          'base': "vs-dark",
          'inherit': false,
          'rules': [{
            'token': 'keyword',
            'foreground': "#F92672"
          }, {
            'token': "identifier",
            'foreground': '#A6E22E'
          }, {
            'token': 'string',
            'foreground': "#E6DB74"
          }, {
            'token': 'number',
            'foreground': "#AE81FF"
          }, {
            'token': "comment",
            'foreground': "#75715E"
          }, {
            'token': "operator",
            'foreground': '#F92672'
          }, {
            'token': 'delimiter',
            'foreground': "#F8F8F2"
          }],
          'colors': {
            'editor.background': '#272822',
            'editor.foreground': '#F8F8F2',
            'editor.lineHighlightBackground': "#3E3D32",
            'editorLineNumber.foreground': "#75715E",
            'editor.selectionBackground': "#49483E",
            'tab.activeBackground': "#272822",
            'tab.inactiveBackground': "#3E3D32",
            'tab.border': "#ff0000",
            'tab.activeBorderTop': "#ff0000"
          }
        },
        'dracula': {
          'base': 'vs-dark',
          'inherit': false,
          'rules': [{
            'token': "keyword",
            'foreground': "#FF79C6"
          }, {
            'token': "identifier",
            'foreground': '#50FA7B'
          }, {
            'token': 'string',
            'foreground': "#F1FA8C"
          }, {
            'token': "number",
            'foreground': "#BD93F9"
          }, {
            'token': "comment",
            'foreground': "#6272A4"
          }, {
            'token': 'operator',
            'foreground': "#FF79C6"
          }, {
            'token': 'delimiter',
            'foreground': '#F8F8F2'
          }],
          'colors': {
            'editor.background': "#282A36",
            'editor.foreground': '#F8F8F2',
            'editor.lineHighlightBackground': "#44475A",
            'editorLineNumber.foreground': "#6272A4",
            'editor.selectionBackground': "#44475A",
            'tab.activeBackground': "#282A36",
            'tab.inactiveBackground': "#44475A",
            'tab.border': "#ff0000",
            'tab.activeBorderTop': "#ff0000"
          }
        },
        'nord': {
          'base': "vs-dark",
          'inherit': false,
          'rules': [{
            'token': "keyword",
            'foreground': "#81A1C1"
          }, {
            'token': "identifier",
            'foreground': "#88C0D0"
          }, {
            'token': "string",
            'foreground': "#A3BE8C"
          }, {
            'token': "number",
            'foreground': "#B48EAD"
          }, {
            'token': "comment",
            'foreground': "#4C566A"
          }, {
            'token': "operator",
            'foreground': "#81A1C1"
          }, {
            'token': "delimiter",
            'foreground': "#ECEFF4"
          }],
          'colors': {
            'editor.background': "#2E3440",
            'editor.foreground': '#D8DEE9',
            'editor.lineHighlightBackground': "#3B4252",
            'editorLineNumber.foreground': "#4C566A",
            'editor.selectionBackground': '#434C5E',
            'tab.activeBackground': "#2E3440",
            'tab.inactiveBackground': '#3B4252',
            'tab.border': "#ff0000",
            'tab.activeBorderTop': "#ff0000"
          }
        }
      };
      this.settings = {
        'editor': {
          'fontSize': 0xe,
          'fontFamily': "Consolas, monospace",
          'tabSize': 0x4,
          'insertSpaces': true,
          'wordWrap': 'on',
          'lineNumbers': 'on',
          'renderWhitespace': "none",
          'autoClosingBrackets': true,
          'autoIndent': true,
          'smoothScrolling': true,
          'cursorBlinking': "blink",
          'cursorStyle': "line"
        },
        'theme': 'vs-dark'
      };
      document.querySelector('.new-tab-btn').addEventListener('click', () => this.createNewTab());
      document.querySelector(".tabs").addEventListener('click', _0x39fbec => this.handleTabClick(_0x39fbec));
      this.initMonaco().then(() => {
        setTimeout(() => this.hideLoadingScreen(), 0xbb8);
      });
      this.setupSettingsPanel();
    }
    ["updateThemeColors"](_0xd1c8c) {
      const _0x52d3d3 = this.themes[_0xd1c8c];
      const _0x44e35e = document.documentElement.style;
      _0x44e35e.setProperty("--tab-active-bg", _0x52d3d3.colors['tab.activeBackground']);
      _0x44e35e.setProperty("--tab-inactive-bg", _0x52d3d3.colors['tab.inactiveBackground']);
      _0x44e35e.setProperty('--tab-border', _0x52d3d3.colors['tab.border']);
      _0x44e35e.setProperty('--tab-active-border', _0x52d3d3.colors['tab.activeBorderTop']);
      _0x44e35e.setProperty("--editor-bg", _0x52d3d3.colors["editor.background"]);
    }
    async ['initMonaco']() {
      require.config({
        'paths': {
          'vs': "https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.36.1/min/vs"
        }
      });
      await new Promise(_0x18e605 => {
        require(['vs/editor/editor.main'], () => {
          Object.entries(this.themes).forEach(([_0xde4b85, _0x1fcc1b]) => {
            monaco.editor.defineTheme(_0xde4b85, _0x1fcc1b);
          });
          monaco.languages.register({
            'id': 'lua'
          });
          monaco.languages.setMonarchTokensProvider("lua", {
            'defaultToken': '',
            'tokenPostfix': ".lua",
            'keywords': ["and", 'break', 'do', "else", 'elseif', "end", "false", 'for', "function", 'if', 'in', 'local', 'nil', 'not', 'or', 'repeat', "return", "then", "true", "until", "while"],
            'operators': ['+', '-', '*', '/', '%', '^', '#', '==', '~=', '<=', '>=', '<', '>', '='],
            'symbols': /[=><!~?:&|+\-*\/\^%]+/,
            'tokenizer': {
              'root': [[/--.*$/, "comment"], [/[a-zA-Z_]\w*/, {
                'cases': {
                  '@keywords': "keyword",
                  '@default': 'identifier'
                }
              }], [/[0-9]+([.][0-9]+)?/, "number"], [/"([^"\\]|\\.)*$/, "string.invalid"], [/'([^'\\]|\\.)*$/, "string.invalid"], [/"/, 'string', "@string_double"], [/'/, "string", '@string_single']],
              'string_double': [[/[^\\"]+/, "string"], [/"/, 'string', "@pop"]],
              'string_single': [[/[^\\']+/, 'string'], [/'/, 'string', "@pop"]]
            }
          });
          const _0x256ded = [...['print', "type", "tostring", 'tonumber', "assert", "error", "ipairs", "pairs", "next", "pcall", "xpcall", "select", "require", "load", "loadfile", "dofile", "rawget", 'rawset', "rawequal", "setmetatable", "getmetatable", 'collectgarbage'].map(_0x195bf0 => ({
            'label': _0x195bf0,
            'kind': monaco.languages.CompletionItemKind.Function,
            'insertText': _0x195bf0,
            'detail': "Lua Standard Library"
          })), ...["math.abs", "math.acos", "math.asin", 'math.atan', "math.ceil", 'math.cos', "math.deg", "math.exp", "math.floor", "math.log", "math.max", "math.min", "math.pi", 'math.rad', "math.random", "math.randomseed", "math.sin", "math.sqrt", "math.tan"].map(_0x5cf519 => ({
            'label': _0x5cf519,
            'kind': monaco.languages.CompletionItemKind.Function,
            'insertText': _0x5cf519,
            'detail': "Math Library"
          })), ...["string.byte", "string.char", 'string.dump', 'string.find', "string.format", "string.gmatch", "string.gsub", "string.len", 'string.lower', 'string.match', 'string.rep', "string.reverse", "string.sub", "string.upper"].map(_0x5db821 => ({
            'label': _0x5db821,
            'kind': monaco.languages.CompletionItemKind.Function,
            'insertText': _0x5db821,
            'detail': "String Library"
          })), ...['table.concat', "table.insert", "table.remove", "table.sort", "table.unpack"].map(_0x2adc7f => ({
            'label': _0x2adc7f,
            'kind': monaco.languages.CompletionItemKind.Function,
            'insertText': _0x2adc7f,
            'detail': "Table Library"
          })), ...["printidentity", 'warn', 'Instance.new', "Vector3.new", "CFrame.new", "task.wait", "task.spawn", "task.delay", "game:GetService", "workspace", 'script', "getfenv", "setfenv"].map(_0x37c647 => ({
            'label': _0x37c647,
            'kind': monaco.languages.CompletionItemKind.Function,
            'insertText': _0x37c647,
            'detail': "Roblox API"
          })), {
            'label': "function",
            'kind': monaco.languages.CompletionItemKind.Snippet,
            'insertText': ["function ${1:name}(${2:params})", "\t${3:-- body}", "end"].join("\n"),
            'insertTextRules': monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            'detail': "Function definition"
          }, {
            'label': 'for',
            'kind': monaco.languages.CompletionItemKind.Snippet,
            'insertText': ["for ${1:i} = ${2:1}, ${3:10} do", "\t${4:-- body}", 'end'].join("\n"),
            'insertTextRules': monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
            'detail': "Numeric for loop"
          }];
          monaco.languages.registerCompletionItemProvider("lua", {
            'provideCompletionItems': () => {
              return {
                'suggestions': _0x256ded
              };
            }
          });
          this.editor = monaco.editor.create(document.getElementById("monaco-editor"), {
            'value': '',
            'language': "lua",
            'theme': "vs-dark",
            'automaticLayout': true,
            'tabSize': 0x2,
            'insertSpaces': true,
            'autoIndent': "full",
            'quickSuggestions': true,
            'suggestOnTriggerCharacters': true
          });
          document.querySelector(".theme-selector").addEventListener("change", _0x5b8396 => {
            monaco.editor.setTheme(_0x5b8396.target.value);
            this.updateThemeColors(_0x5b8396.target.value);
          });
          this.updateThemeColors('vs-dark');
          this.createNewTab();
          _0x18e605();
        });
      });
    }
    ["createNewTab"](_0xd1cc93 = "untitled.lua") {
      const _0x316803 = new EditorTab(_0xd1cc93);
      this.tabs.push(_0x316803);
      const _0x5489c1 = _0x316803.createTabElement();
      document.querySelector(".tabs").appendChild(_0x5489c1);
      setTimeout(() => {
        this.switchToTab(_0x316803);
      }, 0x32);
    }
    ['switchToTab'](_0x3025b4) {
      if (this.activeTab) {
        this.activeTab.element.classList.remove('active');
        this.activeTab.content = this.editor.getValue();
      }
      this.activeTab = _0x3025b4;
      _0x3025b4.element.classList.add('active');
      this.editor.setValue(_0x3025b4.content);
    }
    ["handleTabClick"](_0x20c5c6) {
      const _0x2c65c3 = _0x20c5c6.target.closest(".tab");
      if (!_0x2c65c3) {
        return;
      }
      if (_0x20c5c6.target.classList.contains("tab-close")) {
        this.closeTab(_0x2c65c3);
      } else {
        const _0x36d484 = this.tabs.find(_0x1f9d79 => _0x1f9d79.element === _0x2c65c3);
        if (_0x36d484) {
          this.switchToTab(_0x36d484);
        }
      }
    }
    ["closeTab"](_0x47b9bc) {
      const _0x574c18 = this.tabs.findIndex(_0x2fd8c4 => _0x2fd8c4.element === _0x47b9bc);
      if (_0x574c18 === -0x1) {
        return;
      }
      _0x47b9bc.classList.add("closing");
      setTimeout(() => {
        if (this.activeTab.element === _0x47b9bc) {
          const _0x41fde2 = this.tabs[Math.max(0x0, _0x574c18 - 0x1)];
          if (_0x41fde2) {
            this.switchToTab(_0x41fde2);
          }
        }
        this.tabs.splice(_0x574c18, 0x1);
        _0x47b9bc.remove();
        if (this.tabs.length === 0x0) {
          this.createNewTab();
        }
      }, 0xc8);
    }
    ["setupSettingsPanel"]() {
      const _0x1ebbd4 = "\n            <div class=\"settings-backdrop\"></div>\n            <div class=\"settings-panel\">\n                <div class=\"settings-header\">\n                    <div class=\"settings-title\">Editor Settings</div>\n                    <button class=\"settings-close\">×</button>\n                </div>\n                <div class=\"settings-content\">\n                    <div class=\"settings-group\">\n                        <div class=\"settings-group-title\">Editor</div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Font Size</div>\n                            <div class=\"setting-control\">\n                                <input type=\"number\" id=\"setting-fontSize\" value=\"" + this.settings.editor.fontSize + "\" min=\"8\" max=\"32\">\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Font Family</div>\n                            <div class=\"setting-control\">\n                                <select id=\"setting-fontFamily\">\n                                    <option value=\"Consolas, monospace\">Consolas</option>\n                                    <option value=\"'Source Code Pro', monospace\">Source Code Pro</option>\n                                    <option value=\"'Fira Code', monospace\">Fira Code</option>\n                                    <option value=\"'JetBrains Mono', monospace\">JetBrains Mono</option>\n                                </select>\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Tab Size</div>\n                            <div class=\"setting-control\">\n                                <input type=\"number\" id=\"setting-tabSize\" value=\"" + this.settings.editor.tabSize + "\" min=\"1\" max=\"8\">\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"settings-group\">\n                        <div class=\"settings-group-title\">Appearance</div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Word Wrap</div>\n                            <div class=\"setting-control\">\n                                <select id=\"setting-wordWrap\">\n                                    <option value=\"on\">On</option>\n                                    <option value=\"off\">Off</option>\n                                    <option value=\"wordWrapColumn\">Fixed Width</option>\n                                </select>\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Line Numbers</div>\n                            <div class=\"setting-control\">\n                                <select id=\"setting-lineNumbers\">\n                                    <option value=\"on\">On</option>\n                                    <option value=\"off\">Off</option>\n                                    <option value=\"relative\">Relative</option>\n                                </select>\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Smooth Scrolling</div>\n                            <div class=\"setting-control\">\n                                <input type=\"checkbox\" id=\"setting-smoothScrolling\">\n                            </div>\n                        </div>\n                    </div>\n                    <div class=\"settings-group\">\n                        <div class=\"settings-group-title\">Editor Behavior</div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Auto Closing Brackets</div>\n                            <div class=\"setting-control\">\n                                <input type=\"checkbox\" id=\"setting-autoClosingBrackets\">\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Auto Indent</div>\n                            <div class=\"setting-control\">\n                                <input type=\"checkbox\" id=\"setting-autoIndent\">\n                            </div>\n                        </div>\n                        <div class=\"setting-item\">\n                            <div class=\"setting-label\">Quick Suggestions</div>\n                            <div class=\"setting-control\">\n                                <input type=\"checkbox\" id=\"setting-quickSuggestions\">\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </div>\n        ";
      document.body.insertAdjacentHTML("beforeend", _0x1ebbd4);
      const _0x289b97 = document.querySelector(".settings-btn");
      const _0x15e814 = document.querySelector(".settings-panel");
      const _0x2722e7 = document.querySelector(".settings-backdrop");
      const _0x2e3b5f = document.querySelector(".settings-close");
      const _0x122db7 = () => {
        _0x2722e7.classList.add("visible");
        setTimeout(() => _0x15e814.classList.add('visible'), 0x32);
      };
      const _0x22a87a = () => {
        _0x15e814.classList.remove("visible");
        setTimeout(() => _0x2722e7.classList.remove("visible"), 0xc8);
      };
      _0x289b97.addEventListener("click", _0x122db7);
      _0x2e3b5f.addEventListener("click", _0x22a87a);
      _0x2722e7.addEventListener("click", _0x22a87a);
      let _0x48200b;
      const _0x3b7873 = (_0x23904f, _0x43db14) => {
        clearTimeout(_0x48200b);
        _0x48200b = setTimeout(() => {
          if (_0x23904f in this.settings.editor) {
            this.settings.editor[_0x23904f] = _0x43db14;
            this.editor.updateOptions({
              [_0x23904f]: _0x43db14
            });
          }
        }, 0x12c);
      };
      document.querySelectorAll(".setting-control input, .setting-control select").forEach(_0x4ed21b => {
        _0x4ed21b.addEventListener("change", _0x33c26a => {
          const _0x1c87d8 = _0x33c26a.target.id.replace('setting-', '');
          const _0x2fe849 = _0x33c26a.target.type === "checkbox" ? _0x33c26a.target.checked : _0x33c26a.target.value;
          _0x3b7873(_0x1c87d8, _0x2fe849);
        });
        if (_0x4ed21b.type === 'number' || _0x4ed21b.type === "text") {
          _0x4ed21b.addEventListener("input", _0x38afe1 => {
            const _0x24fd3c = _0x38afe1.target.id.replace("setting-", '');
            const _0x100884 = _0x38afe1.target.type === "number" ? parseInt(_0x38afe1.target.value) : _0x38afe1.target.value;
            _0x3b7873(_0x24fd3c, _0x100884);
          });
        }
      });
    }
    ['showWelcomeScreen']() {}
    ['showLoadingScreen']() {
      document.body.insertAdjacentHTML("beforeend", "\n            <div class=\"loading-screen\">\n                <div class=\"loading-content\">\n                    <div class=\"loading-title\">Nightbear</div>\n                    <div class=\"loading-progress\">\n                        <div class=\"progress-bar\"></div>\n                    </div>\n                    <div class=\"loading-author\">Made By Ra3d</div>\n                </div>\n            </div>\n        ");
      setTimeout(() => {
        document.querySelector(".progress-bar").style.width = "100%";
      }, 0x64);
    }
    ["hideLoadingScreen"]() {
      const _0x4014b3 = document.querySelector(".loading-screen");
      _0x4014b3.classList.add("fade-out");
      setTimeout(() => _0x4014b3.remove(), 0x1f4);
    }
  }
  window.onload = () => {
    new Editor();
  };
  function addTab(_0x354437) {
    const _0xc1e1f5 = document.querySelector('.tabs');
    const _0x9948d = document.createElement("div");
    _0x9948d.className = "tab";
    _0x9948d.textContent = _0x354437;
    const _0x3aee44 = document.createElement("button");
    _0x3aee44.className = "close-tab-btn";
    _0x3aee44.textContent = 'X';
    _0x3aee44.onclick = function () {
      _0x9948d.remove();
    };
    _0x9948d.appendChild(_0x3aee44);
    _0xc1e1f5.appendChild(_0x9948d);
  }